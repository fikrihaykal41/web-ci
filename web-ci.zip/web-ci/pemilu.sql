-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 30 Apr 2018 pada 08.17
-- Versi Server: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pemilu`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(1, 'admin', '123');

-- --------------------------------------------------------

--
-- Struktur dari tabel `divisi`
--

CREATE TABLE `divisi` (
  `kode_divisi` varchar(20) NOT NULL,
  `nama_divisi` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `divisi`
--

INSERT INTO `divisi` (`kode_divisi`, `nama_divisi`) VALUES
('AA', 'Acara apa aja'),
('HR', 'Hore'),
('KP', 'Ketua Pelaksana'),
('KS', 'Konsumsi'),
('LG', 'Logistik'),
('PD', 'Pubdok');

-- --------------------------------------------------------

--
-- Struktur dari tabel `fakultas`
--

CREATE TABLE `fakultas` (
  `kode_fakultas` varchar(3) NOT NULL,
  `nama_fakultas` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `fakultas`
--

INSERT INTO `fakultas` (`kode_fakultas`, `nama_fakultas`) VALUES
('FIF', 'Fakultas Informatika'),
('FRI', 'Fakultas Rekayasa Industri');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusan`
--

CREATE TABLE `jurusan` (
  `kode_jurusan` varchar(3) NOT NULL,
  `kode_fakultas` varchar(3) NOT NULL,
  `nama_jurusan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jurusan`
--

INSERT INTO `jurusan` (`kode_jurusan`, `kode_fakultas`, `nama_jurusan`) VALUES
('IF', 'FIF', 'S1 Teknik Informatika'),
('SI', 'FRI', 'S1 Sistem Informasi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `panitia`
--

CREATE TABLE `panitia` (
  `nim` int(10) NOT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `tgllahir` varchar(30) DEFAULT NULL,
  `kode_divisi` varchar(20) NOT NULL,
  `kode_fakultas` varchar(3) NOT NULL,
  `kode_jurusan` varchar(3) NOT NULL,
  `angkatan` varchar(4) DEFAULT NULL,
  `nohp` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `panitia`
--

INSERT INTO `panitia` (`nim`, `nama`, `tgllahir`, `kode_divisi`, `kode_fakultas`, `kode_jurusan`, `angkatan`, `nohp`) VALUES
(34353, 'Dadang Kesbor', '20-02-1998', 'KP', 'FRI', 'SI', '2016', '13245678'),
(22220202, 'jajang', '12-12-2012', 'AA', 'FIF', 'IF', '2015', '21321312'),
(130130130, 'bambang', '12-12-2012', 'KP', 'FIF', 'IF', '2015', '98129712983'),
(1234245353, 'Sukinti Kesbor', '29-09-1998', 'KP', 'FRI', 'SI', '2014', '4536756'),
(1301131131, 'Andrew Kesbor', '12-12-2012', 'KS', 'FRI', 'SI', '2016', '081212121212'),
(1301161332, 'Bodak Kesbor', '12-12-2012', 'PD', 'FIF', 'IF', '2016', '081209120912'),
(1301164245, 'wasSQWWDQW', '12-12-2012', 'KP', 'FRI', 'SI', '2015', '213123132'),
(1301164502, 'Sukonto', '09955', 'HR', 'FIF', 'IF', '2016', '09654');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `divisi`
--
ALTER TABLE `divisi`
  ADD PRIMARY KEY (`kode_divisi`);

--
-- Indexes for table `fakultas`
--
ALTER TABLE `fakultas`
  ADD PRIMARY KEY (`kode_fakultas`);

--
-- Indexes for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`kode_jurusan`),
  ADD KEY `FK_fakultas` (`kode_fakultas`);

--
-- Indexes for table `panitia`
--
ALTER TABLE `panitia`
  ADD PRIMARY KEY (`nim`),
  ADD KEY `FK_jurusan` (`kode_jurusan`),
  ADD KEY `FK_divisi` (`kode_divisi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `jurusan`
--
ALTER TABLE `jurusan`
  ADD CONSTRAINT `FK_fakultas` FOREIGN KEY (`kode_fakultas`) REFERENCES `fakultas` (`kode_fakultas`);

--
-- Ketidakleluasaan untuk tabel `panitia`
--
ALTER TABLE `panitia`
  ADD CONSTRAINT `FK_divisi` FOREIGN KEY (`kode_divisi`) REFERENCES `divisi` (`kode_divisi`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
