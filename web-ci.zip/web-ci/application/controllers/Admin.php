<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('admin_model');
	}

	// kelola panitia //
	public function index(){
		if($this->session->userdata('status') != 'login'){ 
			redirect('/v/login');
		}

		$data = array(
			'panitia' => $this->admin_model->getPanitia(),
			'fakultas' => $this->admin_model->getFakultas(),
			'jurusan' => $this->admin_model->getJurusan(),
			'divisi' => $this->admin_model->getDivisi() 
		);
		$this->load->view('v_calonpanitia', $data);
	}

	public function addCalonPanitia(){
		if(isset($_REQUEST)){
			$data = array(
				'nim' => $this->input->post('nim'),
				'nama' => $this->input->post('nama'),
				'tgllahir' => $this->input->post('tgllahir'),
				'kode_divisi' => $this->input->post('divisi'),
				'kode_fakultas' => $this->input->post('fakultas'),
				'kode_jurusan' => $this->input->post('jurusan'),
				'angkatan' => $this->input->post('angkatan'),
				'nohp' => $this->input->post('nohp')
			);

			if($this->admin_model->add_CalonPanitia($data)){
				if($this->input->post('code') == 'private'){
					$this->session->set_flashdata('msg', '<div class="alert alert-success">Berhasil menambahkan data baru</div><br>');
					redirect('/admin');
				} else {
					$this->session->set_flashdata('msg', '<div class="alert alert-success">Terimakasih atas partisipasinya untuk informasi kedepannya akan kami kabari secepatnya</div><br>');
					redirect('/v/daftarPanitia');
				}
			}
		}
	}

	public function editCalonPanitia(){
		if(isset($_REQUEST)){
			//isi di sini
			$data = array(
				'nama' => $this->input->post('nama'),
				'tgllahir' => $this->input->post('tgllahir'),
				'kode_divisi' => $this->input->post('divisi'),
				'kode_fakultas' => $this->input->post('fakultas'),
				'kode_jurusan' => $this->input->post('jurusan'),
				'angkatan' => $this->input->post('angkatan'),
				'nohp' => $this->input->post('nohp')
			);

			if($this->admin_model->edit_CalonPanitia($this->input->post('nim'), $data)){
				$this->session->set_flashdata('msg', '<div class="alert alert-success">Berhasil mengedit data '.$this->input->post('nama').'</div><br>');
				redirect('/admin');
			}
		}
	}

	public function deleteCalonPanitia($nim){
		if(empty($nim)){
			redirect('/admin');
		} else {
			if($this->admin_model->del_CalonPanitia($nim)){
				$this->session->set_flashdata('msg', '<div class="alert alert-success">Data dengan NIM '.$nim.' telah dihapus</div><br>');
				redirect('/admin');
			}
		}
	}

	//end of kelola panitia

	public function kelolaAdmin(){
		if($this->session->userdata('status') != 'login'){
			redirect('/v/login');
		}
		$data = array(
			'admin' => $this->admin_model->getAdmin(),
		);
		$this->load->view('v_kelolaAdmin',$data);
	}

	// Kelola Admin 1301162112
	public function addAdmin(){
		if(isset($_REQUEST)){
			$data = array(
				'username' => $this->input->post('username'),
				'password' => $this->input->post('password'),
			);
			if ($this->admin_model->check_username($this->input->post('username'))>0) {
				$this->session->set_flashdata('msg', '<div class="alert alert-danger">Username sudah ada</div><br>');
				redirect('/admin/kelolaAdmin');
			}else{
				if($this->admin_model->add_Admin($data)){
					$this->session->set_flashdata('msg', '<div class="alert alert-success">Admin Baru berhasil ditambahkan</div><br>');
						redirect('/admin/kelolaAdmin');
				}
			}
		}
	}

	public function check(){ // 1301162112
		if ($this->admin_model->getPassword($this->input->post('id_admin'))[0]->password==$this->input->post('cr_password')) {
			return TRUE;
		}else{
			return FALSE;
		}
		
	}

	public function editAdmin(){ // 1301162112
		if(isset($_REQUEST)){
			if ($this->check()) {
				if (empty($this->input->post('new_password'))) {
					$data = array(
						'username' => $this->input->post('username')
					);
				}else{
					$data = array(
						'username' => $this->input->post('username'),
						'password' => $this->input->post('new_password')
					);
				}
				

				if($this->admin_model->edit_Admin($this->input->post('id_admin'), $data)){
					$this->session->set_flashdata('msg', '<div class="alert alert-success">Berhasil mengedit data '.$this->input->post('username').'</div><br>');
					redirect('/admin/kelolaAdmin');
				}
				echo "<script>alert('test')</script>";
			}
		}else{

		}
	}

	public function deleteAdmin($username){ // 1301162112
		if(empty($username)){
			redirect('/admin');
		} else {
			if($this->admin_model->del_Admin($username)){
				$this->session->set_flashdata('msg', '<div class="alert alert-success">Data admin dengan username '.$username.' telah dihapus</div><br>');
				redirect('/admin/kelolaAdmin');
			}
		}
	}

	// end Kelola Admin 1301162112

	// Kelola Divisi
	public function keloladivisi(){ //1301164244
		if($this->session->userdata('status') != 'login'){
			redirect('/v/login');
		}

		$data = array(
			'divisi' => $this->admin_model->getDivisi()
		);
		$this->load->view('v_divisi', $data);
	}
 
	public function addDivisi(){ //1301164244
		if(isset($_REQUEST)){
			$data = array(
				'kode_divisi' => $this->input->post('kode_divisi'),
				'nama_divisi' => $this->input->post('nama_divisi')
			);

			if($this->admin_model->add_Divisi($data)){
				if($this->input->post('code') == 'private'){
					$this->session->set_flashdata('msg', '<div class="alert alert-success">Berhasil menambahkan data baru</div><br>');
					redirect('/admin');
				} else {
					$this->session->set_flashdata('msg', '<div class="alert alert-success">Terimakasih atas partisipasinya untuk informasi kedepannya akan kami kabari secepatnya</div><br>');
					redirect('/v/daftarPanitia');
				}
			}
		}
	}

	public function editDivisi(){ //1301164244
		if(isset($_REQUEST)){
			$data = array(
				'kode_divisi' => $this->input->post('kode_divisi'),
				'nama_divisi' => $this->input->post('nama_divisi'),
			);

			if($this->admin_model->edit_Divisi($this->input->post('kode_divisi'), $data)){
				$this->session->set_flashdata('msg', '<div class="alert alert-success">Berhasil mengedit data '.$this->input->post('nama_divisi').'</div><br>');
				redirect('/admin/keloladivisi');
			}
		}
	}

	public function deleteDivisi($kode_divisi){ //1301164244
		if(empty($kode_divisi)){
			redirect('/admin');
		} else {
			if($this->admin_model->del_Divisi($kode_divisi)){
				$this->session->set_flashdata('msg', '<div class="alert alert-success">Data Dengan Kode Divisi '.$kode_divisi.' telah dihapus</div><br>');
				redirect('/admin');
			}
		}
	}

	// end of kelola divisi


	// Kelola Fakultas 1301164012
	public function kelolafakultas(){//1301164012
		$data = array(
			'fakultas' => $this->admin_model->getFakultas()	
		);
		$this->load->view('kelolafakultas',$data);
	}

	public function addFakultas(){//1301164012
		if(isset($_REQUEST)){
			$data = array(
				'kode_fakultas' => $this->input->post('kode_fakultas'),
				'nama_fakultas' => $this->input->post('nama_fakultas')
			);

			$this->admin_model->add_Fakultas($data);
				//if($this->input->post('code') == 'private'){
					$this->session->set_flashdata('msg', '<div class="alert alert-success">Berhasil menambahkan data baru</div><br>');
					redirect('/admin/kelolafakultas');
				//}
			
		}
	}

	public function editFakultas(){//1301164012
		if(isset($_REQUEST)){
			$data = array(
				'kode_fakultas' => $this->input->post('kode_fakultas'),
				'nama_fakultas' => $this->input->post('nama_fakultas')
			);

			if($this->admin_model->edit_Fakultas($this->input->post('kode_fakultas'), $data)){
				$this->session->set_flashdata('msg', '<div class="alert alert-success">Berhasil mengedit data '.$this->input->post('nama').'</div><br>');
				redirect('/admin/kelolafakultas');
			}
		}
	}

	public function deletefakultas($kode_fakultas){//1301164012
		if(empty($kode_fakultas)){
			redirect('/admin/kelolafakultas');
		} else {
			if($this->admin_model->del_Fakultas($kode_fakultas)){
				$this->session->set_flashdata('msg', '<div class="alert alert-success">Data dengan kode fakultas '.$kode_fakultas.' telah dihapus</div><br>');
				redirect('/admin/kelolafakultas');
			}
		}
	}
	//end of kelola fakultas
	
	//kelola jurusan

	public function kelolajurusan(){//1301164012
		$data = array(
			'jurusan' => $this->admin_model->getJurusan(),
			'fakultas' => $this->admin_model->getFakultas()	
		);
		$this->load->view('kelolajurusan',$data);
	}

	public function addJurusan(){//1301164012
		if(isset($_REQUEST)){
			$data = array(
				'kode_fakultas' => $this->input->post('kode_fakultas'),
				'kode_jurusan' => $this->input->post('kode_jurusan'),
				'nama_jurusan' => $this->input->post('nama_jurusan')
			);
			$this->admin_model->add_Jurusan($data);
			$this->session->set_flashdata('msg', '<div class="alert alert-success">Berhasil menambahkan data baru</div><br>');
			redirect('/admin/kelolajurusan');
		}
	}	

	public function editJurusan(){//1301164012
		if(isset($_REQUEST)){
			$data = array(
				'kode_fakultas' => $this->input->post('kode_fakultas'),
				'kode_jurusan' => $this->input->post('kode_jurusan'),
				'nama_jurusan' => $this->input->post('nama_jurusan')
			);

			if($this->admin_model->edit_Jurusan($this->input->post('kode_jurusanori'), $data)){
				$this->session->set_flashdata('msg', '<div class="alert alert-success">Berhasil mengedit data '.$this->input->post('nama').'</div><br>');
				redirect('/admin/kelolajurusan');
			}
		}
	}

	public function deletejurusan($kode_jurusan){//1301164012
		if(empty($kode_jurusan)){
			redirect('/admin/kelolajurusan');
		} else {
			if($this->admin_model->del_Jurusan($kode_jurusan)){
				$this->session->set_flashdata('msg', '<div class="alert alert-success">Data dengan kode jurusan '.$kode_jurusan.' telah dihapus</div><br>');
				redirect('/admin/kelolajurusan');
			}
		}
	}

	//end of kelola jurusan
}
