<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class V extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('admin_model');
	}

	public function index(){ 
		$this->load->view('landingPage');
	}

	public function tatacara(){ 
		$this->load->view('tatacara');
	}

	public function daftarPanitia(){ 
		$data = array(
			'fakultas' => $this->admin_model->getFakultas(),
			'jurusan' => $this->admin_model->getJurusan(),
			'divisi' => $this->admin_model->getDivisi() 
		);
		$this->load->view('daftarPanitia', $data);
	}

	public function login(){ 
		if($this->session->userdata('status') == 'login'){
			redirect('/admin');
		} else {
			$this->load->view('login');	
		}
	}

	public function kandidat1(){ 
		$this->load->view('kandidat1');
	}

	public function kandidat2(){ 
		$this->load->view('kandidat2');
	}

}
