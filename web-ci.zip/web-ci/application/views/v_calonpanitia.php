<!-- 1301162112 -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="shortcut icon" href="<?= base_url() ?>assets/images/kpu.png">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,400i,500,700,900" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/styles.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/homeHeader.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/homeBody.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/homeFooter.css">
  <title>Sosiliasasi Pemilu</title>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="<?= base_url() ?>assets/images/kpu.png" width="90"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>admin">Kelola Calon Panitia</a>
          </li>          
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>admin/kelolafakultas">Kelola Fakultas</a>
          </li>          
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>admin/kelolajurusan">Kelola Jurusan</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>admin/keloladivisi">Kelola Divisi</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>admin/kelolaAdmin">Kelola Admin</a> <!-- 1301162112 -->
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>auth/logout">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- End of Navbar -->
  

  <!--Main Content-->
   <div class="m-content container" style="margin-bottom: 10%;">
      <h1>Data Peserta Pendaftaran Panitia</h1>
      <br>
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addCalonPanitiaModal">Tambah Calon Panitia</button>

      <!-- Modal -->
      <div class="modal fade" id="addCalonPanitiaModal" tabindex="-1" role="dialog" aria-labelledby="addCalonPanitia" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="addCalonPanitiaLabel">Tambah Calon Panitia</h5>
            </div>
            <div class="modal-body">
              <form role="form" method="post" action="<?= base_url() ?>admin/addCalonPanitia">
                <div class="form-group ml-auto">
                  <label for="nama">Nama Lengkap</label>
                  <input type="text" class="boks form-control" id="nama" name="nama" placeholder="contoh : Susi Similikiti">
                </div>
                <div class="form-group ml-auto">
                  <label for="nim">NIM</label>
                  <input type="number" class="boks form-control" id="nim" name="nim" placeholder="contoh : 130xx" >
                </div>
                <div class="form-group">
                  <label for="tgllahir">Tanggal Lahir</label>
                  <input type="text" class="boks form-control" id="tgllahir" name="tgllahir" placeholder="dd-mm-yyyy">
                </div>
                <div class="form-group">
                  <label for="divisi">Divisi</label>
                  <select class="boks form-control" id="divisi" name="divisi">
                    <option>Pilih Divisi</option>
                    <?php
                    foreach($divisi->result() as $d){
                      echo '<option value="'.$d->kode_divisi.'">'.$d->nama_divisi.'</option>';
                    }
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="fakultas">Fakultas</label>
                  <select class="boks form-control" id="fakultas" name="fakultas">
                    <option>Pilih Fakultas</option>
                    <?php
                    foreach($fakultas->result() as $f){
                      echo '<option value="'.$f->kode_fakultas.'">'.$f->nama_fakultas.'</option>';
                    }
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="jurusan">Jurusan</label>
                  <select class="boks form-control" id="jurusan" name="jurusan">
                    <option>Pilih Jurusan</option>
                    <?php
                    foreach($jurusan->result() as $j){
                      echo '<option value="'.$j->kode_jurusan.'" class="'.$j->kode_fakultas.'">'.$j->nama_jurusan.'</option>';
                    }
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="angkatan">Tahun Angkatan</label>
                  <select class="boks form-control" id="angkatan" name="angkatan">
                    <option value="2014" >2014</option>
                    <option value="2015" >2015</option>
                    <option value="2016" >2016</option>
                    <option value="2017" >2017</option>
                    <option value="2018" >2018</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="nohp">Nomor Handphone</label>
                  <input type="number" class="boks form-control" id="nohp" name="nohp" placeholder="0812XXXX">
                </div>
                <input type="hidden" name="code" value="private">
                <button type="submit" class="btn btn-general btn-block" id="submit">Daftar Menjadi Panitia</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- End of Modal -->

      <br><br><br>
      <?php
      if($this->session->flashdata('msg')){
        echo $this->session->flashdata('msg');
      }
      ?>
      <table id="dataTable" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>NIM</th>
                <th>Tanggal Lahir</th>
                <th>Divisi</th>
                <th>Fakultas</th>
                <th>Jurusan</th>
                <th>Angkatan</th>
                <th>Nomer Handphone</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
          <?php
          $i = 1;
          foreach($panitia->result() as $p){
          ?>
          <tr>
            <td><?= $i++ ?></td>
            <td><?= $p->nama ?></td>
            <td><?= $p->nim ?></td>
            <td><?= $p->tgllahir ?></td>
            <td><?= $p->nama_divisi ?></td>
            <td><?= $p->nama_fakultas ?></td>
            <td><?= $p->nama_jurusan ?></td>
            <td><?= $p->angkatan ?></td>
            <td><?= $p->nohp ?></td>
            <td>
              <div class="btn-group">
                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#<?= $p->nim ?>editCalonPanitiaModal">Edit</button>
                <a href="<?= base_url() ?>admin/deleteCalonPanitia/<?= $p->nim ?>" class="btn btn-sm btn-danger">Delete</a>
              </div>
            </td>
          </tr>
           <!-- Modal -->
          <div class="modal fade" id="<?= $p->nim ?>editCalonPanitiaModal" tabindex="-1" role="dialog" aria-labelledby="editCalonPanitia" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="editCalonPanitiaLabel">Edit Calon Panitia</h5>
                </div>
                <div class="modal-body">
                  <form role="form" method="post" action="<?= base_url() ?>admin/editCalonPanitia">
                    <div class="form-group ml-auto">
                      <label for="nim">NIM</label>
                      <input type="number" class="boks form-control" id="nim" name="nima" value="<?= $p->nim ?>" disabled>
                      <input type="hidden" name="nim" value="<?= $p->nim ?>">
                    </div>
                    <div class="form-group ml-auto">
                      <label for="nama">Nama Lengkap</label>
                      <input type="text" class="boks form-control" id="nama" name="nama" value="<?= $p->nama ?>">
                    </div>
                    <div class="form-group">
                      <label for="tgllahir">Tanggal Lahir</label>
                      <input type="text" class="boks form-control" id="tgllahir" name="tgllahir" value="<?= $p->tgllahir ?>">
                    </div>
                    <div class="form-group">
                      <label for="divisi">Divisi</label>
                      <select class="boks form-control" id="divisi2" name="divisi">
                        <option>Pilih Divisi</option>
                        <?php
                        foreach($divisi->result() as $d){
                          if($d->kode_divisi == $p->kode_divisi){
                            echo '<option value="'.$d->kode_divisi.'" selected>'.$d->nama_divisi.'</option>';
                          } else {
                            echo '<option value="'.$d->kode_divisi.'" selected>'.$d->nama_divisi.'</option>';
                          }
                        }
                        ?>
                      </select>
                    </div>

                    <div class="form-group">
                      <label for="fakultas">Fakultas</label>
                      <select class="boks form-control" id="fakultas2" name="fakultas">
                        <option>Pilih Fakultas</option>
                        <?php
                        foreach($fakultas->result() as $f){
                          if($f->kode_fakultas == $p->kode_fakultas){
                            echo '<option value="'.$f->kode_fakultas.'" selected>'.$f->nama_fakultas.'</option>'; 
                          } else {
                            echo '<option value="'.$f->kode_fakultas.'">'.$f->nama_fakultas.'</option>';
                          }
                        }
                        ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="jurusan">Jurusan</label>
                      <select class="boks form-control" id="jurusan2" name="jurusan">
                        <option>Pilih Jurusan</option>
                        <?php
                        foreach($jurusan->result() as $j){
                          if($j->kode_jurusan == $p->kode_jurusan){
                            echo '<option value="'.$j->kode_jurusan.'" class="'.$j->kode_fakultas.'" selected>'.$j->nama_jurusan.'</option>';
                          } else {
                            echo '<option value="'.$j->kode_jurusan.'" class="'.$j->kode_fakultas.'">'.$j->nama_jurusan.'</option>'; 
                          }
                        }
                        ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="angkatan">Tahun Angkatan</label>
                      <select class="boks form-control" id="angkatan" name="angkatan">
                        <?php
                        for($x=2014; $x<=2018; $x++){
                          if($x == $p->angkatan){
                            echo '<option value="'.$x.'" selected>'.$x.'</option>';
                          } else {
                            echo '<option value="'.$x.'">'.$x.'</option>';
                          }
                        }
                        ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="nohp">Nomor Handphone</label>
                      <input type="number" class="boks form-control" id="nohp" name="nohp" value="<?= $p->nohp ?>">
                    </div>
                    <input type="hidden" name="code" value="private">
                    <button type="submit" class="btn btn-general btn-block" id="submit">Edit Data Calon Panitia</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <!-- End of Modal -->
          <?php
          }
          ?>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>NIM</th>
                <th>Tanggal Lahir</th>
                <th>Fakultas</th>
                <th>Jurusan</th>
                <th>Angkatan</th>
                <th>Nomer Handphone</th>
                <th>Actions</th>
            </tr>
        </tfoot>
      </table>
    </div>
  <!--End of Main Content-->

  <!-- Footer -->
  <div class="footer">
    <div class="container">
      <p>©2018 Tubes Website Pemograman. All Rights Reserved</p>
    </div>
  </div>
  <!-- End of Footer -->

</body>

<!-- JS utk table -->
  <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
  integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" 
  integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script type="text/javascript" src="<?= base_url() ?>assets/js/jquery.chained.min.js"></script>

<!-- JS setting -->
<!-- <script type="text/javascript" src="<?= base_url() ?>assets/js/dataTable.js"></script> -->
<script type="text/javascript">
  $(document).ready(function() {
    $('#jurusan').chained('#fakultas');
    $('#jurusan2').chained('#fakultas2');
    $('#dataTable').dataTable({});
  });
</script>


</html>
