<!-- 1301161331 -->
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="shortcut icon" href="<?= base_url() ?>assets/images/kpu.png">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Rubik:300,400,400i,500,700,900" rel="stylesheet">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/styles.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/homeHeader.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/homeBody.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/homeFooter.css">
</head>
<body class="login">

	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6">
				<div class="card" style="margin-top: 30%">
				  <div class="card-body">
				  	<h2>Login</h2>
				  	<br>
				  	<?php
				  	if($this->session->flashdata('msg')){
				  		echo $this->session->flashdata('msg');
				  	}
				  	?>
				  	<form method="post" action="<?= base_url() ?>auth/login">
						<div class="form-group ml-auto">
							<label for="username">Username</label>
							<input type="text" class="boks form-control" id="username" name="username" placeholder="Masukkan username anda disini">
						</div>
						<div class="form-group ml-auto">
							<label for="password">Password</label>
							<input type="password" class="boks form-control" id="password" name="password" placeholder="Masukkan password anda disini" >
						</div>
						<button type="submit" name="submit" class="btn btn-success btn-block">Login Sekarang</button>
					</form>
				  </div>
				</div>
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>

</body>
</html>