<!-- 1301164012 -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="shortcut icon" href="<?= base_url() ?>assets/images/kpu.png">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,400i,500,700,900" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/styles.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/homeHeader.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/homeBody.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/homeFooter.css">
  <title>Sosiliasasi Pemilu</title>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="<?= base_url() ?>assets/images/kpu.png" width="90"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>admin">Kelola Calon Panitia</a>
          </li>          
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>admin/kelolafakultas">Kelola Fakultas</a>
          </li>          
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>admin/kelolajurusan">Kelola Jurusan</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>admin/keloladivisi">Kelola Divisi</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>admin/kelolaAdmin">Kelola Admin</a> <!-- 1301162112 -->
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>auth/logout">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- End of Navbar -->
  

  <!--Main Content-->
   <div class="m-content container" style="margin-bottom: 10%;">
      <h1>Data Jurusan</h1>
      <br>
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addJurusanModal">Tambah Jurusan</button>

      <!-- Modal -->
      <div class="modal fade" id="addJurusanModal" tabindex="-1" role="dialog" aria-labelledby="addJurusan" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="addJurusanLabel">Tambah Jurusan</h5>
            </div>
            <div class="modal-body">
              <form role="form" method="post" action="<?= base_url() ?>admin/addJurusan">
                <div class="form-group">
                  <label for="kode_fakultas">Kode Fakultas</label>
                  <select class="boks form-control" id="kode_fakultas" name="kode_fakultas">
                    <?php
                    foreach($fakultas->result() as $f){
                      echo '<option value="'.$f->kode_fakultas.'">'.$f->nama_fakultas.'</option>';
                    }
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="kode_jurusan">Kode Jurusan</label>
                  <input type="text" class="boks form-control" id="kode_jurusan" name="kode_jurusan" placeholder="IF">
                </div>
                <div class="form-group">
                  <label for="nama_jurusan">Nama Jurusan</label>
                  <input type="text" class="boks form-control" id="nama_jurusan" name="nama_jurusan" placeholder="Teknik Informatika">
                </div>
                <button type="submit" class="btn btn-general btn-block" id="submit">Tambahkan Jurusan</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- End of Modal -->

      <br><br><br>
      <?php
      if($this->session->flashdata('msg')){
        echo $this->session->flashdata('msg');
      }
      ?>
      <table id="dataTable" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Fakultas</th>
                <th>Kode Jurusan</th>
                <th>Jurusan</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
          <?php
          $i = 1;
          foreach($jurusan->result() as $j){
          ?>
          <tr>
            <td><?= $i++ ?></td>
            <td><?= $j->kode_fakultas ?></td>
            <td><?= $j->kode_jurusan ?></td>
            <td><?= $j->nama_jurusan ?></td>
            <td>
              <div class="btn-group">
                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#<?= $j->kode_jurusan ?>editJurusanModal">Edit</button>
                <a href="<?= base_url() ?>admin/deleteJurusan/<?= $j->kode_jurusan ?>" class="btn btn-sm btn-danger">Delete</a>
              </div>
            </td>
          </tr>
           <!-- Modal -->
          <div class="modal fade" id="<?= $j->kode_jurusan ?>editJurusanModal" tabindex="-1" role="dialog" aria-labelledby="editJurusan" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="editJurusanLabel">Edit Jurusan</h5>
                </div>
                <div class="modal-body">
                  <form role="form" method="post" action="<?= base_url() ?>admin/editJurusan">
                    <div class="form-group">
                      <label for="kode_fakultas">Kode Fakultas</label>
                      <select class="boks form-control" id="kode_fakultas" name="kode_fakultas">
                        <option>Pilih Fakultas</option>
                        <?php
                        foreach($fakultas->result() as $f){
                          if($f->kode_fakultas == $j->kode_fakultas){
                            echo '<option value="'.$f->kode_fakultas.'" selected>'.$f->nama_fakultas.'</option>'; 
                          } else {
                            echo '<option value="'.$f->kode_fakultas.'">'.$f->nama_fakultas.'</option>';
                          }
                        }
                        ?>
                    </select>
                    </div>
                    <div class="form-group">
                      <label for="kode_fakultas">Kode Jurusan</label>
                      <input type="text" class="boks form-control" name="kode_jurusan" value="<?= $j->kode_jurusan ?>">
                      <input type="hidden" name="kode_jurusanori" value="<?= $j->kode_jurusan ?>">
                    </div>
                    <div class="form-group ml-auto">
                      <label for="nama">Nama Jurusan</label>
                      <input type="text" class="boks form-control" id="nama_jurusan" name="nama_jurusan" value="<?= $j->nama_jurusan ?>">
                    </div>
                    <button type="submit" class="btn btn-general btn-block" id="submit">Edit Jurusan</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <!-- End of Modal -->
          <?php
          }
          ?>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Kode Fakultas</th>
                <th>Kode Jurusan</th>
                <th>Nama Jurusan</th>
                <th>Actions</th>
            </tr>
        </tfoot>
      </table>
    </div>
  <!--End of Main Content-->

  <!-- Footer -->
  <div class="footer">
    <div class="container">
      <p>©2018 Tubes Website Pemograman. All Rights Reserved</p>
    </div>
  </div>
  <!-- End of Footer -->

</body>

<!-- JS utk table -->
  <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
  integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" 
  integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script type="text/javascript" src="<?= base_url() ?>assets/js/jquery.chained.min.js"></script>

<!-- JS setting -->
<!-- <script type="text/javascript" src="<?= base_url() ?>assets/js/dataTable.js"></script> -->
<script type="text/javascript">
  $(document).ready(function() {
    $('#jurusan').chained('#fakultas');
    $('#jurusan2').chained('#fakultas2');
    $('#dataTable').dataTable({});
});
</script>


</html>
