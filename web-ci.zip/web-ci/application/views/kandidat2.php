<!-- 1301161331 -->
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Kandidat</title>
    <link rel="shortcut icon" href="<?= base_url() ?>assets/images/kpu.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,400i,500,700,900" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url() ?>assets/css/styles.css">
  </head>
  <body>


    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">
        <a class="navbar-brand" href="index.html"><img src="assets/images/kpu.png" width="90"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url() ?>">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url() ?>v/tatacara">Tata Cara Pemilihan</a>
            </li>
            <li class="nav-item">
              <a class="btn btn-general" href="<?= base_url() ?>v/daftarpanitia">Daftar Menjadi Panitia</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- End of Navbar -->


    <!-- Main Content -->
    <div class="m-content container">
      <div class="head row">
        <div class="col-md">
          <img src="<?= base_url() ?>assets/images/orang/2.png" class="img-fluid rounded">
        </div>
        <div class="col-md">
          <h1>#2 Kabinet Ayo Kerja</h1>
          <h6>VISI</h6>
          <p>Badan Eksekutif Mahasiswa andalan masyarakat, yang berperan sebagai pilar penting pergerakan Indonesia.</p>
          <br>
          <h6>MISI</h6>
          <p>Membangun institusi yang unggul di bidang penyelesaian pembayaran dan solusi keuangan bagi nasabah bisnis dan perseorangan.
Memahami beragam kebutuhan nasabah dan memberikan layanan finansial yang tepat demi tercapainya kepuasan optimal bagi nasabah.
Meningkatkan nilai francais dan nilai stakeholder ABC</p>
        </div>
      </div>
      <hr class="divider">
      <div class="row">
        <div class="col">
          <div class="bio">
            <img src="<?= base_url() ?>assets/images/orang/o4.png" class="img-fluid rounded">
            <br>
            <small>CALON PRESMA</small>
            <h5>Afrian Hanafi</h5>
            <p>S1 Teknik Informatika '16</p>
          </div>
          <div class="bio">
            <h6>PENGALAMAN</h6>
            <ul>
              <li>Ketua pelaksana Fortran 2019</li>
              <li>Kepala divisi kaderisasi kabinet muda 2017</li>
            </ul>
          </div>
          <div class="bio">
            <h6>PRESTASI</h6>
            <ul>
              <li>Juara 1 Moestopo Dentistry Scientific Programme Kategori Literature Review</li>
              <li>Juara 2 Lomba Karya Tulis Ilmiah Nasional FKG Universitas Andalas</li>
              <li>Juara 2 Lomba Poster Infografik Pepsodent</li>
              <li>Juara 2 Video Contest Kolaborasi Profesi Kesehatan Universitas Andalas</li>
            </ul>
          </div>
        </div>
        <div class="col-md-1"></div>
        <div class="col-md-5">
          <div class="bio">
            <img src="<?= base_url() ?>assets/images/orang/o3.png" class="img-fluid rounded">
            <br>
            <small>CALON WAPRESMA</small>
            <h5>Edgarsa Bramandyo W</h5>
            <p>S1 Teknik Mesin '16</p>
          </div>

          <div class="bio">
            <h6>PENGALAMAN</h6>
            <ul>
              <li>Ketua pelaksana Fortran 2019</li>
              <li>Kepala divisi kaderisasi kabinet muda 2017</li>
            </ul>
          </div>
          <div class="bio">
            <h6>PRESTASI</h6>
            <ul>
              <li>Juara 1 Moestopo Dentistry Scientific Programme Kategori Literature Review</li>
              <li>Juara 2 Lomba Karya Tulis Ilmiah Nasional FKG Universitas Andalas</li>
              <li>Juara 2 Lomba Poster Infografik Pepsodent</li>
              <li>Juara 2 Video Contest Kolaborasi Profesi Kesehatan Universitas Andalas</li>
            </ul>
          </div>
        </div>

        <div class="col-md-1"></div>
      </div>
    </div>
    <!-- End of Main Content -->

    <!-- Daftar Menjadi Panitia Section -->
    <div class="closing">
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <h2>Daftar Menjadi Panitia</h2>
            <p>Ayo bergabung bersama kami dan menciptakan suasana pemilu <br> yang aman, tentram dan transparan.</p>
          </div>
          <div class="col-md-4">
            <a href="<?= base_url() ?>v/daftarpanitia" class="btn btn-general">Daftar Sekarang</a>
          </div>
        </div>
      </div>
    </div>
    <!-- End of Daftar Menjadi Panitia Section -->

    <!-- Footer -->
    <div class="footer">
      <div class="container">
        <p>©2018 Tubes Website Pemograman. All Rights Reserved</p>
      </div>
    </div>
    <!-- End of Footer -->

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
