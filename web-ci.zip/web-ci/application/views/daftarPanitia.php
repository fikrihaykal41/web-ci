<!-- 1301164012 -->
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Form Pendaftaran</title>
	
	<link rel="shortcut icon" href="<?= base_url() ?>assets/images/kpu.png">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Rubik:300,400,400i,500,700,900" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/css/form.css">

</head>
<body>
	<!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">
        <a class="navbar-brand" href="<?= base_url() ?>"><img src="<?= base_url() ?>assets/images/kpu.png" width="90"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url() ?>">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url() ?>v/tatacara">Tata Cara Pemilihan</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- End of Navbar -->

    <!-- Main Content -->
	<div class="m-content container ml-auto">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6">
				<center>
				<h1 class="kepala">Daftar Menjadi Panitia</h1>
				<p style="color: grey; margin-bottom: 40px;">Berikut ini adalah form pendaftaran panitia. Dimohon agar bersungguh sungguh dalam mengisi.</p>
				<br>
				<?php
				if($this->session->userdata('msg')){
					echo $this->session->userdata('msg');
				}
				?>
				</center>
				<form role="form" method="post" action="<?= base_url() ?>admin/addCalonPanitia">
					<div class="form-group ml-auto">
						<label for="nama">Nama Lengkap</label>
						<input type="text" class="boks form-control" id="nama" name="nama" placeholder="contoh : Susi Similikiti">
					</div>
					<div class="form-group ml-auto">
						<label for="nim">NIM</label>
						<input type="number" class="boks form-control" id="nim" name="nim" placeholder="contoh : 130xx" >
					</div>
					<div class="form-group">
						<label for="tgllahir">Tanggal Lahir</label>
						<input type="text" class="boks form-control" id="tgllahir" name="tgllahir" placeholder="dd-mm-yyyy">
					</div>
					<div class="form-group">
						<label for="divisi">Divisi</label>
							<select class="boks form-control" id="divisi" name="divisi">
								<option>Pilih Divisi</option>
									<?php
										foreach($divisi->result() as $d){
											echo '<option value="'.$d->kode_divisi.'">'.$d->nama_divisi.'</option>';
										}
									?>
							</select>
					</div>
	                <div class="form-group">
	                  <label for="fakultas">Fakultas</label>
	                  <select class="boks form-control" id="fakultas" name="fakultas">
	                    <option>Pilih Fakultas</option>
	                    <?php
	                    foreach($fakultas->result() as $f){
	                      echo '<option value="'.$f->kode_fakultas.'">'.$f->nama_fakultas.'</option>';
	                    }
	                    ?>
	                  </select>
	                </div>
	                <div class="form-group">
	                  <label for="jurusan">Jurusan</label>
	                  <select class="boks form-control" id="jurusan" name="jurusan">
	                    <option>Pilih Jurusan</option>
	                    <?php
	                    foreach($jurusan->result() as $j){
	                      echo '<option value="'.$j->kode_jurusan.'" class="'.$j->kode_fakultas.'">'.$j->nama_jurusan.'</option>';
	                    }
	                    ?>
	                  </select>
	                </div>
					<div class="form-group">
						<label for="angkatan">Tahun Angkatan</label>
						<select class="boks form-control" id="angkatan" name="angkatan">
							<option value="2014" >2014</option>
							<option value="2015" >2015</option>
							<option value="2016" >2016</option>
							<option value="2017" >2017</option>
							<option value="2018" >2018</option>
						</select>
					</div>
					<div class="form-group">
						<label for="noHp">Nomor Handphone</label>
						<input type="number" class="boks form-control" id="nohp" name="nohp" placeholder="0812XXXX">
					</div>
					<input type="hidden" name="code" value="public">
					<button type="submit" class="btn btn-general btn-block" id="submit">Daftar Menjadi Panitia</button>
				</form>
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>
	<!-- End of Main Content -->

  <!-- Footer -->
    <div class="footer" style="margin-top:100px;">
      <div class="container">
        <p>©2018 Tubes Website Pemograman. All Rights Reserved</p>
      </div>
    </div>
    <!-- End of Footer -->

    <!-- JS default-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
	<script type="text/javascript" src="<?= base_url() ?>assets/js/jquery.chained.min.js"></script>

    <!-- JS setting -->
	<!-- <script type="text/javascript" src="<?= base_url() ?>assets/js/formValidation.js"></script> -->
	<script type="text/javascript">
	  $(document).ready(function() {
	    $('#jurusan').chained('#fakultas');
	});
	</script>

</body>
</html>
