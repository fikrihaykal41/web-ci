<!-- 1301164244 -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="shortcut icon" href="<?= base_url() ?>assets/images/kpu.png">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,400i,500,700,900" rel="stylesheet">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/styles.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/homeHeader.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/homeBody.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/homeFooter.css">

  <title>Sosiliasasi Pemilu</title>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="<?= base_url() ?>assets/images/kpu.png" width="90"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?= base_url() ?>v/tatacara">Tata Cara Pemilihan</a>
          </li>
          <li class="nav-item">
            <a class="btn btn-general" href="<?= base_url() ?>v/daftarPanitia">Daftar Menjadi Panitia</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- End of Navbar -->
  <!--Head-->
  <div class="headd">
    <div class="container">
      <div class="top">
        <div class="row">
          <div class="col-md-8">
            <div class="caption">
              <h1 id="tittle">Sosiliasasi Pemilu</h1>
              <p>Mari kita ramaikan pesta demokrasi ini dengan cara turut memilih<br>calon-calon yang akan menjadi wakil negara tercinta kita ini.</p>
              <br>
              <a class="btn btn-general" href="<?= base_url() ?>v/tatacara">Lihat Tata Cara Pemilihan</a>
            </div>
          </div>
          <div class="col-md-4">
            <img src="assets/images/input.png" class="img-fluid" alt="">
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--End of Head-->

  <!--Main Content-->
  <div class="container kandidat">
    <h1>Kandidat</h1>
    <p>Berikut adalah calon pemimpin kita.</p>
    <br>
    <div class="row">
      <div class="col-md">
        <a href="<?= base_url() ?>v/kandidat1">
          <img src="assets/images/orang/1.png" class="img-fluid rounded">
        </a>
        <br><br>
        <a href="<?= base_url() ?>v/kandidat1"><h3>#1 Kabinet Gotong Royong</h3></a>
      </div>
      <div class="col-md">
        <a href="<?= base_url() ?>v/kandidat2">
          <img src="assets/images/orang/2.png" class="img-fluid rounded">
        </a>
        <br><br>
        <a href="<?= base_url() ?>v/kandidat2"><h3>#2 Kabinet Ayo Kerja</h3></a>
      </div>
    </div>
  </div>

  <div class="container">
    <h1>Roadmap Pemilu</h1>
    <p>Berikut adalah jadwal kegiatan acara selama pemilu berlangsung.</p>
    <div class="kampanye">
      <h3 class="headsection">Kampanye</h3>
      <div class="row">
        <div class="col-md-2">
          <small class="date">MINGGU,7 DES 2017</small>
          <h6>Kampanye Perdana Kandidat Nomor #1</h6>
          <div class="boxx"></div>
        </div>
        <div class="col-md-2">
          <small class="date">MINGGU,7 DES 2017</small>
          <h6>Kampanye Perdana Kandidat Nomor #1</h6>
          <div class="boxx"></div>
        </div>
        <div class="col-md-2">
          <small class="date">MINGGU,7 DES 2017</small>
          <h6>Kampanye Perdana Kandidat Nomor #1</h6>
          <div class="boxx"></div>
        </div>
        <div class="col-md-2">
          <small class="date">MINGGU,7 DES 2017</small>
          <h6>Kampanye Perdana Kandidat Nomor #1</h6>
          <div class="boxx"></div>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="mumilu">
      <div class="row">
        <div class="col-md-4">
          <h3 class="headsection">Musyawarah Besar</h3>
          <div class="row">
            <div class="col">
              <small class="date">MINGGU,7 DES 2017</small>
              <h6>Kampanye Perdana Kandidat Nomor #1</h6>
              <div class="boxx"></div>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <h3 class="headsection">Pelaksanaan Pemilu</h3>
          <div class="row">
            <div class="col">
              <small class="date">MINGGU,7 DES 2017</small>
              <h6>Kampanye Perdana Kandidat Nomor #1</h6>
              <div class="boxx"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--End of Main Content-->

  <!-- Daftar Menjadi Panitia Section -->
  <div class="closing">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <h2>Daftar Menjadi Panitia</h2>
          <p>Ayo bergabung bersama kami dan menciptakan suasana pemilu <br> yang aman, tentram dan transparan.</p>
        </div>
        <div class="col-md-4">
          <a href="<?= base_url() ?>/v/daftarPanitia" class="btn btn-general">Daftar Sekarang</a>
        </div>
      </div>
    </div>
  </div>
  <!-- End of Daftar Menjadi Panitia Section -->

  <!-- Footer -->
  <div class="footer">
    <div class="container">
      <p>©2018 Tubes Website Pemograman. All Rights Reserved</p>
    </div>
  </div>
  <!-- End of Footer -->

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
