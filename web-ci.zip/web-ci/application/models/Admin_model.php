<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {

	public function __construct(){
		parent::__construct();
	}

	public function getPanitia(){ 
		$this->db->join('fakultas', 'panitia.kode_fakultas = fakultas.kode_fakultas');
		$this->db->join('jurusan', 'fakultas.kode_fakultas = jurusan.kode_fakultas');
		$this->db->join('divisi', 'panitia.kode_divisi = divisi.kode_divisi');
		return $this->db->get('panitia');
	}

	public function getFakultas(){ 
		$this->db->order_by('nama_fakultas','asc');
		return $this->db->get('fakultas');
	}

	public function getJurusan(){ 
		$this->db->order_by('nama_jurusan', 'asc');
		$this->db->join('fakultas', 'jurusan.kode_fakultas = fakultas.kode_fakultas');
		return $this->db->get('jurusan');
	}

	public function getSelectedJurusan($kode_jurusan){ 
		$this->db->where('kode_jurusan', $kode_jurusan);
		$this->db->join('fakultas', 'jurusan.kode_fakultas = fakultas.kode_fakultas');
		return $this->db->get('jurusan');
	}

	public function add_CalonPanitia($data){ 
		return $this->db->insert('panitia', $data);
	}

	public function edit_CalonPanitia($nim, $data){ 
		$this->db->set($data);
		$this->db->where('nim', $nim);
		return $this->db->update('panitia');
	}

	public function del_calonPanitia($nim){ 
		$this->db->where('nim', $nim);
		return $this->db->delete('panitia');
	}

	// Kelola Admin 1301162112
	public function getAdmin(){ 
		return $this->db->get('admin');
	}

	public function add_Admin($data){ 
		return $this->db->insert('admin', $data);
	}

	public function edit_Admin($id_admin, $data){ 
		$this->db->set($data);
		$this->db->where('id_admin', $id_admin);
		return $this->db->update('admin');
	}

	public function del_Admin($username){ 
		$this->db->where('username', $username);
		return $this->db->delete('admin');
	}

	public function check_username($username){ 
		$this->db->where('username', $username);
		return $this->db->count_all_results('admin');	
	}

	public function getPassword($id){ 
		$this->db->where('id_admin', $id);
		return $this->db->get('admin')->result();	
	}
	// end Kelola Admin 1301162112

	//Divisi
	public function getDivisi(){ 
		$this->db->order_by('nama_divisi','asc');
		return $this->db->get('divisi');
	}

	public function add_Divisi($data){ 
		return $this->db->insert('divisi', $data);
	}

	public function edit_Divisi($kode_divisi, $data){ 
		$this->db->set($data);
		$this->db->where('kode_divisi', $kode_divisi);
		return $this->db->update('divisi');
	}
 
	public function del_Divisi($kode_divisi){ 
		$this->db->where('kode_divisi', $kode_divisi);
		return $this->db->delete('divisi');
	}
	//End Of Divisi

	// Kelola Fakultas & Jurusan 1301164012
	public function add_Fakultas($data){ 
		return $this->db->insert('fakultas', $data);
	}	

	public function edit_Fakultas($kode_fakultas, $data){ 
		$this->db->set($data);
		$this->db->where('kode_fakultas', $kode_fakultas);
		return $this->db->update('fakultas');
	}

	public function del_Fakultas($kode_fakultas){ 
		$this->db->where('kode_fakultas', $kode_fakultas);
		return $this->db->delete('fakultas');
	}

	public function add_Jurusan($data){ 
		return $this->db->insert('jurusan', $data);
	}	

	public function edit_Jurusan($kode_jurusan, $data){ 
		$this->db->set($data);
		$this->db->where('kode_jurusan', $kode_jurusan);
		return $this->db->update('jurusan');
	}

	public function del_Jurusan($kode_Jurusan){ 
		$this->db->where('kode_jurusan', $kode_Jurusan);
		return $this->db->delete('jurusan');
	}

	public function getJurusann(){ 
		$this->db->join('fakultas', 'jurusan.kode_fakultas = fakultas.kode_fakultas');
		return $this->db->get('jurusan');
	}
	//End Of fakultas & jurusan
	

}
