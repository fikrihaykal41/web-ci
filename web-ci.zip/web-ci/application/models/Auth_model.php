<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model {

	public function __construct(){
		parent::__construct();
	}

	public function login($c){
		$validate = $this->db->get_where('admin','username = "'.$c['username'].'" AND password = "'.$c['password'].'"');
		if($validate->num_rows() > 0){
			return true;
		} else {
			return false;
		}
	}

}
